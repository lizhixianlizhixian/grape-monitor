<template>
  <el-dialog
    v-model="dialogVisible"
    width="460px"
    :show-close="false"
    align-center
  >
    <div class="login-card">
      <h2 class="login-title">葡萄甜了 - 农户甜度监测系统</h2>
      <el-tabs v-model="activeTab">
        <!-- 登录 -->
        <el-tab-pane label="账号登录" name="login">
          <el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" label-width="80px">
            <el-form-item label="手机号" prop="phone">
              <el-input v-model="loginForm.phone" placeholder="请输入绑定手机号" clearable />
            </el-form-item>
            <el-form-item label="密码" prop="pwd">
              <el-input v-model="loginForm.pwd" show-password placeholder="请输入密码" />
            </el-form-item>
            <el-form-item>
              <el-switch v-model="remember" label="记住农户账号" />
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                color="#d87093"
                style="width:100%"
                @click="submitLogin"
              >登录系统</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>

        <!-- 注册 -->
        <el-tab-pane label="农户注册" name="register">
          <el-form ref="regFormRef" :model="regForm" :rules="regRules" label-width="80px">
            <el-form-item label="农户昵称" prop="roleName">
              <el-input v-model="regForm.roleName" placeholder="填写农户/果园名称"/>
            </el-form-item>
            <el-form-item label="手机号" prop="phone">
              <el-input v-model="regForm.phone" placeholder="作为登录账号" clearable/>
            </el-form-item>
            <el-form-item label="登录密码" prop="pwd">
              <el-input v-model="regForm.pwd" show-password placeholder="设置登录密码"/>
            </el-form-item>
            <el-form-item label="葡萄品种" prop="grapeType">
              <el-select v-model="regForm.grapeType" placeholder="请选择品种" style="width:100%">
                <el-option label="阳光玫瑰" value="ygmg" />
                <el-option label="巨峰" value="jf" />
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                color="#d87093"
                style="width:100%"
                @click="submitRegister"
              >完成注册</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
      </el-tabs>
    </div>
  </el-dialog>
</template>

<script setup>
/* eslint-disable no-undef */
import { ref, watch, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
// ✅【修复】路径更正为 /user
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()

const props = defineProps({
  visible: Boolean
})
const emit = defineEmits(['update:visible', 'login-success'])

const dialogVisible = ref(false)
watch(() => props.visible, val => dialogVisible.value = val)
watch(dialogVisible, val => emit('update:visible', val))

const activeTab = ref('login')
const remember = ref(false)

// =========登录表单=========
const loginFormRef = ref(null)
const loginForm = ref({
  phone: '',
  pwd: ''
})
const loginRules = ref({
  phone: [{ required: true, message: '请填写手机号', trigger: 'blur' }],
  pwd: [{ required: true, message: '请填写密码', trigger: 'blur' }]
})

// =========注册表单=========
const regFormRef = ref(null)
const regForm = ref({
  roleName: '',
  phone: '',
  pwd: '',
  grapeType: ''
})
const regRules = ref({
  roleName: [{ required: true, message: '请填写农户名称', trigger: 'blur' }],
  phone: [{ required: true, message: '请填写手机号', trigger: 'blur' }],
  pwd: [{ required: true, message: '设置登录密码', trigger: 'blur' }],
  grapeType: [{ required: true, message: '选择葡萄品种', trigger: 'change' }]
})

// 打开弹窗时读取记住的手机号
onMounted(() => {
  const savedPhone = localStorage.getItem('farmPhone')
  if (savedPhone) {
    loginForm.value.phone = savedPhone
    remember.value = true
  }
})

// 登录提交
const submitLogin = async () => {
  await loginFormRef.value.validate()
  // 查询本地注册信息
  const userStr = localStorage.getItem('farmUser_' + loginForm.value.phone)
  if (!userStr) {
    return ElMessage.error('账号不存在，请先注册')
  }
  const userInfo = JSON.parse(userStr)
  if (userInfo.pwd !== loginForm.value.pwd) {
    return ElMessage.error('密码错误')
  }

  // 参数顺序完美匹配userStore
  userStore.login(loginForm.value.phone, userInfo.roleName, userInfo.grapeType)

  // 是否记住账号
  if (remember.value) {
    localStorage.setItem('farmPhone', loginForm.value.phone)
  } else {
    localStorage.removeItem('farmPhone')
  }
  emit('login-success')
}

// 注册提交
const submitRegister = async () => {
  await regFormRef.value.validate()
  const key = 'farmUser_' + regForm.value.phone
  if (localStorage.getItem(key)) {
    return ElMessage.warning('该手机号已经注册！')
  }
  // 保存注册信息
  localStorage.setItem(key, JSON.stringify({
    roleName: regForm.value.roleName,
    phone: regForm.value.phone,
    pwd: regForm.value.pwd,
    grapeType: regForm.value.grapeType
  }))
  ElMessage.success('注册成功，请前往登录')
  activeTab.value = 'login'
  loginForm.value.phone = regForm.value.phone
}
</script>

<style scoped>
.login-card {
  padding: 10px 4px;
}
.login-title {
  text-align: center;
  color: #a06484;
  margin-bottom: 16px;
  font-size: 24px;
}
:deep(.el-dialog__body) {
  padding: 10px 20px 24px !important;
}
</style>