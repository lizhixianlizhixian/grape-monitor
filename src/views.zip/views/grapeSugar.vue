<template>
  <PageHeader />
  <div class="global-bg">
    <div class="grape-sugar-page">
      <div class="page-title">葡萄甜度趋势预测｜把握最佳采摘时机</div>
      <div class="tab-group">
        <div
          class="tab-item"
          :class="{ active: chartType === 'line' }"
          @click="switchChartType('line')"
        >
          折线图
        </div>
        <div
          class="tab-item"
          :class="{ active: chartType === 'bar' }"
          @click="switchChartType('bar')"
        >
          柱状图
        </div>
        <div
          class="tab-item"
          :class="{ active: dataRange === '7day' }"
          @click="switchTab('7day')"
        >
          预估后七日
        </div>
        <div
          class="tab-item"
          :class="{ active: dataRange === '14day' }"
          @click="switchTab('14day')"
        >
          预估后十四日
        </div>
        <el-button
          type="primary"
          style="background:#d87093;border-color:#d87093;margin-left:20px"
          @click="exportChart"
        >
          导出图表数据
        </el-button>
      </div>
      <div class="chart-box" ref="chartRef"></div>

      <div class="device-card-wrap">
        <el-button
          class="arrow-btn arrow-left"
          circle
          @click="prevDevice"
        >
          <el-icon><ArrowLeft /></el-icon>
        </el-button>
        <el-button
          class="arrow-btn arrow-right"
          circle
          @click="nextDevice"
        >
          <el-icon><ArrowRight /></el-icon>
        </el-button>

        <div
          v-for="dev in deviceList"
          :key="dev.id"
          class="info-card"
          :class="{ active: selectDeviceId === dev.id }"
          @click="openEditDevice(dev)"
        >
          <div class="card-title">{{ dev.name }}</div>
          <div class="card-desc">{{ dev.greenhouse }} · {{ dev.variety }}</div>
        </div>

        <div v-if="deviceList.length === 0" class="empty-card-tip">
          当前暂无监测设备，请点击右侧箭头添加设备
        </div>
      </div>

      <!-- 编辑设备弹窗 -->
      <el-dialog v-model="editDevDialogVisible" title="编辑监测设备信息" width="540px">
        <el-form :model="editDevForm" label-width="110px">
          <el-form-item label="检测器名称">
            <el-input v-model="editDevForm.name" placeholder="葡萄检测器3号" />
          </el-form-item>
          <el-form-item label="大棚位置">
            <el-input v-model="editDevForm.greenhouse" placeholder="新大棚 / 东区5号大棚" />
          </el-form-item>
          <el-form-item label="葡萄品种">
            <el-input v-model="editDevForm.variety" placeholder="阳光玫瑰 / 巨峰" />
          </el-form-item>
          <el-form-item label="最佳采收甜度">
            <el-input-number v-model="editDevForm.standardSugar" :min="10" :max="25" />
            <span style="margin-left:8px">°Bx</span>
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="editDevDialogVisible = false">取消</el-button>
          <el-button type="primary" style="background:#d87093;border-color:#d87093" @click="saveEditDevice">保存修改</el-button>
        </template>
      </el-dialog>

      <div class="switch-card">
        <el-switch v-model="globalRemindConfig.sugarBest" size="large" active-color="#d87093" />
        <span class="switch-text">甜度最佳时提醒我</span>
        <el-tag v-if="globalRemindConfig.sugarBest" color="#f8c8dc">已开启提醒</el-tag>
      </div>
      <div class="bottom-nav">
        <div class="nav-logo">葡萄甜了LOGO</div>
        <div class="nav-item" @click="router.push('/device')">设备链接</div>
        <div class="nav-item" @click="openUserDrawer">个人中心</div>
      </div>

      <el-drawer
        v-model="userDrawerOpen"
        title="个人中心设置"
        direction="rtl"
        size="360px"
        destroy-on-close
      >
        <div class="user-drawer-content">
          <el-card shadow="never">
            <template #header>
              <span>账号基础信息</span>
            </template>
            <el-form ref="userFormRef" :model="userInfo" label-width="80px">
              <el-form-item label="用户名">
                <el-input v-model="userInfo.nickname" placeholder="请输入昵称" />
              </el-form-item>
              <el-form-item label="绑定设备">
                <el-select
                  v-model="userInfo.deviceId"
                  placeholder="选择监测设备"
                  @change="onSelectDeviceFromDrawer"
                >
                  <el-option
                    v-for="dev in deviceList"
                    :key="dev.id"
                    :label="`${dev.name}（${dev.greenhouse} · ${dev.variety}）`"
                    :value="dev.id"
                  />
                </el-select>
              </el-form-item>
              <el-form-item label="绑定手机号">
                <el-input v-model="userInfo.phone" placeholder="接收短信提醒" />
              </el-form-item>
            </el-form>
          </el-card>
          <el-divider />
          <el-card shadow="never">
            <template #header>
              <span>全局消息提醒设置</span>
            </template>
            <el-row class="remind-row">
              <el-col :span="20">甜度达标自动推送采摘提醒</el-col>
              <el-col :span="4">
                <el-switch v-model="globalRemindConfig.sugarBest" active-color="#d87093" />
              </el-col>
            </el-row>
            <el-row class="remind-row">
              <el-col :span="20">甜度下降异常预警</el-col>
              <el-col :span="4">
                <el-switch v-model="globalRemindConfig.sugarDrop" active-color="#d87093" />
              </el-col>
            </el-row>
            <el-row class="remind-row">
              <el-col :span="20">设备低电量提醒</el-col>
              <el-col :span="4">
                <el-switch v-model="globalRemindConfig.deviceLowPower" active-color="#d87093" />
              </el-col>
            </el-row>
            <el-row class="remind-row">
              <el-col :span="20">传感器离线断连提醒</el-col>
              <el-col :span="4">
                <el-switch v-model="globalRemindConfig.deviceOffline" active-color="#d87093" />
              </el-col>
            </el-row>
            <el-row class="remind-row">
              <el-col :span="20">浏览器弹窗推送</el-col>
              <el-col :span="4">
                <el-switch v-model="globalRemindConfig.browserNotice" active-color="#d87093" />
              </el-col>
            </el-row>
          </el-card>
          <el-divider />
          <div class="drawer-btn-group">
            <el-button
              type="primary"
              style="background:#d87093;border-color:#d87093"
              @click="saveUserConfig"
            >
              保存设置
            </el-button>
            <el-button @click="closeUserDrawer">关闭</el-button>
            <el-button type="danger" @click="logout">退出账号</el-button>
          </div>
        </div>
      </el-drawer>
    </div>
    <img class="vine-asset" src="/images/asset.png" alt="葡萄藤蔓">
  </div>
</template>

<script setup>
import { useUserStore } from '@/stores/userStore'
import { ref, onMounted, watch, onBeforeUnmount, onActivated, computed } from 'vue'
import { ElMessage, ElMessageBox, ElIcon } from 'element-plus'
import { ArrowLeft, ArrowRight } from '@element-plus/icons-vue'
import * as echarts from 'echarts'
import * as XLSX from 'xlsx'
import PageHeader from './PageHeader.vue'
import { useRouter } from 'vue-router'
const router = useRouter()

const userStore = useUserStore()
const chartRef = ref(null)
let chartInstance = null
let resizeTimer = null

const isLogin = computed(() => !!userStore.username)
const selectDeviceId = ref('')

// ============ 设备编辑弹窗状态 ============
const editDevDialogVisible = ref(false)
const editDevForm = ref({})
let editingDevId = ref(null)

// ============ 响应式设备、甜度模板 ============
const deviceList = ref([])
const deviceSugarTemplate = ref({})

// 获取当前下标
const currentIndex = computed(() => {
  return deviceList.value.findIndex(item => item.id === selectDeviceId.value)
})

// ============ localStorage 按账号key隔离存储 ============
function getStorageKey(type) {
  const phone = userStore.username || 'temp'
  return `farm_${phone}_${type}`
}

/** 保存本账号设备和甜度模板 */
function saveDeviceStorage() {
  localStorage.setItem(getStorageKey('deviceList'), JSON.stringify(deviceList.value))
  localStorage.setItem(getStorageKey('sugarTpl'), JSON.stringify(deviceSugarTemplate.value))
}

/** 读取本账号设备 */
function loadDeviceStorage() {
  const devStr = localStorage.getItem(getStorageKey('deviceList'))
  const tplStr = localStorage.getItem(getStorageKey('sugarTpl'))
  if (devStr) deviceList.value = JSON.parse(devStr)
  if (tplStr) deviceSugarTemplate.value = JSON.parse(tplStr)

  // 兜底：没有设备初始化两套默认设备
  if (deviceList.value.length === 0) {
    initDefaultDevice()
  }
  // 选中项边界保护
  if (deviceList.value.length > 0) {
    const exist = deviceList.value.some(d => d.id === selectDeviceId.value)
    if (!exist) {
      selectDeviceId.value = deviceList.value[0].id
    }
  } else {
    selectDeviceId.value = ''
  }
}

/** 初始化默认两套设备 */
function initDefaultDevice() {
  const d1 = {
    id: '1',
    name: '葡萄检测器一号',
    greenhouse: '东区5号大棚',
    variety: '阳光玫瑰'
  }
  const d5 = {
    id: '5',
    name: '葡萄检测器五号',
    greenhouse: '西区2号大棚',
    variety: '巨峰'
  }
  deviceList.value = [d1, d5]
  deviceSugarTemplate.value['1'] = {
    name: '阳光玫瑰',
    standardSugar: 18,
    '7day': [16.2, 16.8, 17.5, 18.1, 18.6, 18.3, 17.9],
    '14day': [16.2,16.8,17.5,18.1,18.6,18.3,17.9,17.6,17.2,16.9,16.5,16.3,16.1,15.8]
  }
  deviceSugarTemplate.value['5'] = {
    name: '巨峰',
    standardSugar: 16,
    '7day': [14.1,14.8,15.2,15.7,16.3,16.1,15.5],
    '14day': [14.1,14.8,15.2,15.7,16.3,16.1,15.5,15.1,14.8,14.5,14.2,13.9,13.6,13.3]
  }
  selectDeviceId.value = d1.id
  saveDeviceStorage()
}

/** 生成一套全新设备甜度模板 */
function createNewSugarTpl() {
  return {
    name: '新监测点',
    standardSugar: 15,
    '7day': [13.0, 13.4, 13.8, 14.2, 14.6, 15.1, 14.8],
    '14day': [12.8,13.1,13.5,13.9,14.3,14.7,15.0,14.9,14.6,14.2,13.9,13.6,13.3,13.0]
  }
}

// ============ 打开编辑弹窗 ============
const openEditDevice = (dev) => {
  editingDevId.value = dev.id
  const tpl = deviceSugarTemplate.value[dev.id]
  editDevForm.value = {
    name: dev.name,
    greenhouse: dev.greenhouse,
    variety: dev.variety,
    standardSugar: tpl?.standardSugar || 15
  }
  editDevDialogVisible.value = true
}

// ============ 保存编辑设备 ============
const saveEditDevice = () => {
  const devItem = deviceList.value.find(i => i.id === editingDevId.value)
  if (devItem) {
    devItem.name = editDevForm.value.name
    devItem.greenhouse = editDevForm.value.greenhouse
    devItem.variety = editDevForm.value.variety
  }
  if (deviceSugarTemplate.value[editingDevId.value]) {
    deviceSugarTemplate.value[editingDevId.value].standardSugar = editDevForm.value.standardSugar
  }
  saveDeviceStorage()
  editDevDialogVisible.value = false
  renderChart()
  ElMessage.success('设备信息修改完成')
}

// ============ 左右箭头核心逻辑 ============
const prevDevice = async () => {
  if (deviceList.value.length === 0) return
  if (currentIndex.value === 0) {
    try {
      await ElMessageBox.confirm(
        '当前已经是第一个设备，确认删除第一项设备？设备全部甜度预测数据也会一并清除！',
        '删除确认',
        { confirmButtonText: '确认删除', cancelButtonText: '取消', type: 'warning' }
      )
      const delId = deviceList.value[0].id
      deviceList.value.shift()
      delete deviceSugarTemplate.value[delId]

      if (deviceList.value.length > 0) {
        selectDeviceId.value = deviceList.value[0].id
      } else {
        selectDeviceId.value = ''
      }
      userInfo.value.deviceId = selectDeviceId.value
      saveDeviceStorage()
    } catch {
      return
    }
  } else {
    const newIdx = currentIndex.value - 1
    selectDeviceId.value = deviceList.value[newIdx].id
    userInfo.value.deviceId = selectDeviceId.value
  }
}

const nextDevice = async () => {
  if (deviceList.value.length === 0 || currentIndex.value >= deviceList.value.length - 1) {
    try {
      await ElMessageBox.confirm(
        deviceList.value.length === 0
          ? '暂无监测设备，确认添加新监测设备？'
          : '已经是最后一台设备，确认新增一台监测设备？',
        '新增确认',
        { confirmButtonText: '确认添加', cancelButtonText: '取消', type: 'info' }
      )
      const newId = Date.now().toString()
      const newDev = {
        id: newId,
        name: `葡萄检测器${deviceList.value.length + 1}号`,
        greenhouse: '新大棚',
        variety: '未知品种'
      }
      deviceList.value.push(newDev)
      deviceSugarTemplate.value[newId] = createNewSugarTpl()
      selectDeviceId.value = newId
      userInfo.value.deviceId = newId
      saveDeviceStorage()
    } catch {
      return
    }
  } else {
    const newIdx = currentIndex.value + 1
    selectDeviceId.value = deviceList.value[newIdx].id
    userInfo.value.deviceId = selectDeviceId.value
  }
}

let baseDate = new Date()

const formatMonthDay = (date) => {
  const m = date.getMonth() + 1
  const d = date.getDate()
  return `${m}.${d}`
}

function buildDateList(startDate, count) {
  const list = []
  for(let i = 0; i < count; i++){
    const temp = new Date(startDate)
    temp.setDate(startDate.getDate() + i)
    list.push(formatMonthDay(temp))
  }
  return list
}

const getCurrentData = () => {
  if (!selectDeviceId.value || !deviceSugarTemplate.value[selectDeviceId.value]) {
    return { xData: [], sugarData: [] }
  }
  const template = deviceSugarTemplate.value[selectDeviceId.value]
  const sugarArr = template[dataRange.value]
  const startDay = new Date(baseDate)
  startDay.setDate(baseDate.getDate() - 1)
  const xData = buildDateList(startDay, sugarArr.length)
  return {
    xData,
    sugarData: sugarArr
  }
}

const getCurrentStandard = () => {
  if (!selectDeviceId.value || !deviceSugarTemplate.value[selectDeviceId.value]) return 15
  return deviceSugarTemplate.value[selectDeviceId.value].standardSugar
}

const chartType = ref('line')
const dataRange = ref('7day')

const userDrawerOpen = ref(false)
const userFormRef = ref(null)
const userInfo = ref({
  nickname: '',
  deviceId: '',
  phone: ''
})

const globalRemindConfig = ref({
  sugarBest: false,
  sugarDrop: false,
  deviceLowPower: false,
  deviceOffline: false,
  browserNotice: false
})

const loadUserDeviceConfig = () => {
  const currentPhone = userStore.username
  if (!currentPhone) {
    selectDeviceId.value = ''
    return
  }
  loadDeviceStorage()

  const localInfoStr = localStorage.getItem('farmInfo_' + currentPhone)
  if (localInfoStr) {
    const info = JSON.parse(localInfoStr)
    selectDeviceId.value = info.deviceId || (deviceList.value[0]?.id || '')
    userInfo.value.deviceId = selectDeviceId.value
    userInfo.value.nickname = info.nickname || ''
    userInfo.value.phone = info.phone || ''
    if(info.remindSetting){
      globalRemindConfig.value = {...info.remindSetting}
    }
  } else {
    selectDeviceId.value = deviceList.value[0]?.id || ''
    userInfo.value.deviceId = selectDeviceId.value
  }
}

const renderChart = () => {
  if (!chartInstance) return
  const currentData = getCurrentData()
  if(currentData.xData.length === 0){
    chartInstance.clear()
    return
  }
  const STANDARD_SUGAR = getCurrentStandard()

  const option = {
    backgroundColor: '#0f172a',
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(255,255,255,0.95)',
      textStyle: { color: '#333', fontSize: 14 },
      formatter: (params) => {
        const date = params[0].axisValue
        const sugarParam = params.find((p) => p.seriesName === '葡萄甜度')
        const value = sugarParam ? sugarParam.data : '-'
        let tipStr = `<div>日期：${date}</div><div>当日平均甜度：${value} °Bx</div>`
        if (value !== '-' && value >= STANDARD_SUGAR) {
          tipStr += `<div style="color:green">✅ 达到最佳采收甜度${STANDARD_SUGAR}度</div>`
        } else {
          tipStr += `<div style="color:#ff6666">❌ 未到最佳采收甜度</div>`
        }
        return tipStr
      }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      name: '日期',
      nameTextStyle: { color: '#eee' },
      axisLine: { lineStyle: { color: '#444' } },
      axisLabel: { color: '#ccc' },
      data: currentData.xData
    },
    yAxis: {
      type: 'value',
      name: '甜度值 °Bx',
      nameTextStyle: { color: '#eee' },
      splitLine: { lineStyle: { color: '#222' } },
      axisLine: { lineStyle: { color: '#444' } },
      axisLabel: { color: '#ccc' },
      min: 0,
      max: 22
    },
    series: [
      {
        name: '采收标准线',
        type: 'line',
        data: Array(currentData.xData.length).fill(STANDARD_SUGAR),
        lineStyle: { color: '#ff4d4f', width: 2, type: 'dashed' },
        symbol: 'none',
        label: {
          show: true,
          position: 'end',
          formatter: `最佳采收${STANDARD_SUGAR}度`,
          color: '#ff4d4f'
        }
      },
      {
        name: '葡萄甜度',
        type: chartType.value,
        data: currentData.sugarData,
        smooth: chartType.value === 'line',
        itemStyle: { color: '#d87093' },
        lineStyle: { width: 3 },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(216,112,147,0.4)' },
            { offset: 1, color: 'rgba(216,112,147,0.05)' }
          ])
        }
      }
    ]
  }
  chartInstance.setOption(option)
}

const openUserDrawer = () => {
  if (!isLogin.value) {
    ElMessage.warning('请先登录账号！')
    router.push('/login')
    return
  }
  loadUserDeviceConfig()
  userDrawerOpen.value = true
}

const closeUserDrawer = () => (userDrawerOpen.value = false)

const onSelectDeviceFromDrawer = () => {
  selectDeviceId.value = userInfo.value.deviceId
}

const initChart = () => {
  chartInstance = echarts.init(chartRef.value)
  renderChart()
}

const switchChartType = (type) => {
  chartType.value = type
}

const switchTab = (type) => {
  dataRange.value = type
}

const exportChart = () => {
  if (!chartInstance) {
    ElMessage.warning('图表尚未初始化，无法导出')
    return
  }
  const currentData = getCurrentData()
  if(currentData.xData.length ===0){
    ElMessage.warning('暂无设备数据，无法导出')
    return
  }
  const imgUrl = chartInstance.getDataURL({ pixelRatio: 2 })
  const aImg = document.createElement('a')
  aImg.href = imgUrl
  aImg.download = `葡萄甜度曲线图_${dataRange.value}.png`
  aImg.click()

  const tableData = currentData.xData.map((date, idx) => {
    return {
      监测日期: date,
      当日甜度: currentData.sugarData[idx],
      是否达标: currentData.sugarData[idx] >= getCurrentStandard() ? '达标可采摘' : '未达标'
    }
  })
  const sheet = XLSX.utils.json_to_sheet(tableData)
  const book = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(book, sheet, '甜度数据')
  XLSX.writeFile(book, `葡萄甜度数据表_${dataRange.value}.xlsx`)
  ElMessage.success('图表图片+Excel数据导出成功！')
}

const saveUserConfig = () => {
  const currentPhone = userStore.username
  if (!currentPhone) {
    ElMessage.warning('请先登录！')
    return
  }
  const saveInfo = {
    nickname: userInfo.value.nickname,
    phone: userInfo.value.phone,
    deviceId: selectDeviceId.value,
    remindSetting: {...globalRemindConfig.value}
  }
  localStorage.setItem('farmInfo_' + currentPhone, JSON.stringify(saveInfo))
  saveDeviceStorage()
  ElMessage.success('个人设置保存成功！')
  closeUserDrawer()
}

const logout = async () => {
  await ElMessageBox.confirm('确定退出当前农户账号吗？', '操作确认', {
    confirmButtonText: '确认退出',
    cancelButtonText: '取消',
    type: 'warning'
  })
  const currentPhone = userStore.username
  localStorage.removeItem(getStorageKey('deviceList'))
  localStorage.removeItem(getStorageKey('sugarTpl'))
  localStorage.removeItem('farmInfo_' + currentPhone)
  userStore.logout()
  userDrawerOpen.value = false
  deviceList.value = []
  deviceSugarTemplate.value = {}
  selectDeviceId.value = ''
  ElMessage.success('账号已退出，请重新登录')
  router.push('/login')
}

watch([chartType, dataRange, selectDeviceId], () => renderChart())

const handleResize = () => {
  clearTimeout(resizeTimer)
  resizeTimer = setTimeout(() => chartInstance?.resize(), 100)
}

onMounted(() => {
  loadUserDeviceConfig()
  initChart()
  window.addEventListener('resize', handleResize)
})

onActivated(() => {
  loadUserDeviceConfig()
  if (chartInstance) {
    renderChart()
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
  clearTimeout(resizeTimer)
  chartInstance?.dispose()
})
</script>

<style scoped>
.grape-sugar-page {
  position: relative;
  width: 100%;
  min-height: 100vh;
  padding: 40px 20px 140px;
  box-sizing: border-box;
  height: auto;
}
.vine-asset {
  position: fixed;
  top: 0;
  width: 90vw;
  pointer-events: none;
  z-index: 1;
}
.global-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: linear-gradient(160deg, #f0fcf9 0%, #e6f7f2 100%);
  z-index: -1;
}
.page-title {
  width: 100%;
  text-align: center;
  font-size: 30px;
  font-weight: 600;
  color: #a05773;
  margin-bottom: 24px;
  letter-spacing: 1px;
}
.tab-group {
  display: flex;
  align-items: center;
  gap: 16px;
  justify-content: center;
  margin-bottom: 16px;
}
.tab-item {
  background: #1a1a1a;
  color: #f8c8dc;
  font-size: 20px;
  padding: 8px 22px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.25s ease;
  border: 1px solid transparent;
}
.tab-item:hover {
  background: #2d2d2d;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(216, 112, 147, 0.2);
}
.tab-item.active {
  background: linear-gradient(135deg, #c8688c, #d87093);
  color: #fff;
  border-color: #f8c8dc;
  box-shadow: 0 4px 14px rgba(216, 112, 147, 0.35);
}
.chart-box {
  width: calc(100% - 40px);
  max-width: 1200px;
  height: 340px;
  margin: 0 auto;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}
.device-card-wrap {
  position: relative;
  display: flex;
  gap: 30px;
  max-width: 1200px;
  margin: 30px auto 32px;
  padding: 0 60px;
  box-sizing: border-box;
  min-height:140px;
  align-items:center;
}
.empty-card-tip{
  width:100%;
  text-align:center;
  color:#999;
  font-size:17px;
}
:deep(.arrow-btn) {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  z-index: 10;
  width:42px;
  height:42px;
  background:#fff;
  border-color:#d87093;
  color:#d87093;
}
:deep(.arrow-btn.arrow-left) {
  left:10px;
}
:deep(.arrow-btn.arrow-right) {
  right:10px;
}

.info-card {
  flex: 1;
  background: #fff;
  padding: 22px 28px;
  border-radius: 14px;
  box-shadow: 0 4px 16px rgba(216, 112, 147, 0.1);
  border-left: 6px solid #d87093;
  transition: 0.24s ease;
  cursor: pointer;
}
.info-card.active {
  background: #fff5f9;
  box-shadow: 0 6px 20px rgba(216, 112, 147, 0.25);
  transform: translateY(-4px);
}
.info-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 22px rgba(216, 112, 147, 0.18);
}
.card-title {
  font-size: 22px;
  color: #a05773;
  font-weight: 600;
  margin-bottom: 8px;
}
.card-desc {
  font-size: 16px;
  color: #666;
}
.switch-card {
  display: flex;
  align-items: center;
  gap: 18px;
  max-width: 1200px;
  margin: 0 auto 80px;
  background: #fff;
  padding: 20px 26px;
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
}
.switch-text {
  font-size: 22px;
  color: #a05773;
  font-weight: 500;
}
.bottom-nav {
  display: flex;
  justify-content: space-around;
  align-items: center;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 90px;
  background: #ffffff;
  box-shadow: 0 -2px 18px rgba(0, 0, 0, 0.08);
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
}
.nav-logo {
  font-size: 28px;
  color: #fff;
  background: linear-gradient(135deg, #c8688c, #d87093);
  padding: 8px 24px;
  border-radius: 12px;
  font-weight: bold;
}
.nav-item {
  font-size: 22px;
  color: #a05773;
  padding: 8px 16px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
}
.nav-item:hover {
  background: #f8e8ef;
  color: #d87093;
}
.user-drawer-content {
  padding: 10px 0;
}
.remind-row {
  margin: 16px 0;
  align-items: center;
  display: flex;
}
.drawer-btn-group {
  margin-top: 30px;
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}
</style>