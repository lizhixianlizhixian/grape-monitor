<template>
<div class="header-box">
  <!-- 使用isLogin判断登录状态 -->
  <span v-if="!userStore.isLogin" class="login-btn" @click="dialogVisible = true">请登录</span>
  <div v-else class="user-info">
    <span>欢迎你，{{ userStore.roleName }}</span>
    <span class="logout" @click="handleLogout">退出登录</span>
  </div>

  <!-- 弹窗状态交给组件内部管理，不再依赖pinia -->
  <LoginDialog v-model:visible="dialogVisible" @login-success="onLoginSuccess"/>
</div>
</template>

<script setup>
/* eslint-disable vue/multi-word-component-names */
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import LoginDialog from './LoginDialog.vue'

const router = useRouter()
const userStore = useUserStore()
// 弹窗状态放在当前组件内
const dialogVisible = ref(false)

// 登录成功回调
const onLoginSuccess = () => {
  dialogVisible.value = false
  router.push('/grapeSugar')
}

// 退出登录
const handleLogout = () => {
  userStore.logout()
  router.push('/')
}
</script>

<style scoped>
.header-box{
  position: fixed;
  top:16px;
  right:32px;
  z-index: 999;
}
.login-btn{
  cursor: pointer;
  color:#d87093;
  font-size:16px;
}
.user-info span{
  color:#a05773;
  font-size:16px;
}
.logout{
  margin-left:16px;
  cursor:pointer;
  color:#666;
}
.logout:hover{
  color:#d87093;
}
</style>